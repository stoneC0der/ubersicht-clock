# Changelog

## 0.1.0

- Initial release

## 0.2.0

- Add optional date to widget (uses local format 02/17/2022 for english, to enable date display, change the value of **showDate** in the .jsx file to **true** to show the widget date)